# flaskLoginReg
Login and registration using Flask


What do I do with this??
1. FORK this repository. You will get your own copy as a remote repo.

2. CLONE your copy into your local machine.

3. Add a directory all your own that contains your login and registration

4. PUSH to your repository

5. Submit a PULL REQUEST so that your changes will be merged with this repository.


This way, we can all contribute to Login and Registration and you'll be able to easily share how you completed this assignment.

And now you know how to contribute to open source projects!
